# Monster-Hunters
Monster-Hunters được viết bằng C++ sử dụng thư viện SDL 2.0
<div align="center">
  <h1>
    Monster-Hunters
  </h1>
  <img src="https://media.discordapp.net/attachments/971965145192489010/1103358674111565926/image.png?width=1137&height=662" width="250"/>
</div>

---

#  LUẬT CHƠI :
- Người chơi cố gắng sống sót qua thời gian quy định và tiêu diệt các quái vật xuất hiện 
- Có 3 chế độ chơi : Dễ, Trung bình, Khó ( chế độ khó sẽ xuất hiện Boss ngay đầu màn chơi với lượng máu lớn)

---

# CÁCH CHƠI
- W hoặc ↑ : di chuyển lên trên
- A hoặc ← : di chuyển sang trái
- S hoặc ↓ : di chuyển xuống dưới
- D hoặc → : di chuyển sang phải
- SPACE hoặc nhấn chuột : tấn công
- ESC : thoát hoặc tạm dừng
